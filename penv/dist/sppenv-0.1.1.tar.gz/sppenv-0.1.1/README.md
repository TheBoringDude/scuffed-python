# penv

Simplified Python `.env` file parser.