# dotdict
Simple Class-based .dot notation on dictionaries.