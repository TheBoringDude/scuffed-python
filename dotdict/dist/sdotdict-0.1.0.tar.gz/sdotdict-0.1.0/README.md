# sdotdict
Simple Class-based .dot notation on dictionaries.